# Android APK构建指南

## 前提条件

要构建此Flutter应用的Android APK，您需要以下工具和环境：

1. **Flutter SDK**：确保已安装最新版本的Flutter SDK
2. **Android Studio**：用于Android开发和SDK管理
3. **Java Development Kit (JDK)**：至少JDK 8或更高版本
4. **Android SDK**：包括构建工具和平台工具
5. **Git**：用于版本控制和获取代码

## 构建步骤

### 1. 克隆项目代码

```bash
git clone <项目仓库URL>
cd telegram_whatsapp_translator/flutter_app
```

### 2. 获取依赖项

```bash
flutter pub get
```

### 3. 配置API密钥

在使用真实API之前，您需要获取并配置以下API密钥：

1. 打开 `lib/src/services/translation_service.dart` 文件
2. 将 `_baiduAppId` 和 `_baiduAppSecret` 替换为您的百度翻译API密钥
3. 保存文件

### 4. 配置Telegram API

1. 在 [Telegram API开发者网站](https://my.telegram.org/apps) 注册一个应用
2. 获取API ID和API Hash
3. 打开 `lib/src/services/telegram_service.dart` 文件
4. 将API ID和API Hash添加到适当的位置
5. 保存文件

### 5. 构建APK

#### 调试版本

```bash
flutter build apk --debug
```

调试版本的APK将位于 `build/app/outputs/flutter-apk/app-debug.apk`

#### 发布版本

```bash
flutter build apk --release
```

发布版本的APK将位于 `build/app/outputs/flutter-apk/app-release.apk`

### 6. 安装到设备

您可以使用以下命令将APK安装到连接的设备上：

```bash
flutter install
```

或者手动将APK文件传输到设备并安装。

## 签名配置（发布版本）

对于发布版本，您需要创建一个签名密钥：

1. 在项目根目录下创建 `android/key.properties` 文件
2. 添加以下内容：

```
storePassword=<密钥库密码>
keyPassword=<密钥密码>
keyAlias=<密钥别名>
storeFile=<密钥库文件路径>
```

3. 修改 `android/app/build.gradle` 文件，添加签名配置

## 常见问题

1. **构建失败**：确保所有依赖项都已正确安装，并且Flutter SDK是最新版本
2. **API密钥错误**：检查API密钥是否正确配置
3. **TDLib集成问题**：确保TDLib库已正确配置和链接

## 注意事项

- 此应用使用了TDLib，可能需要额外的配置步骤
- 确保您的设备允许安装来自未知来源的应用
- 发布到应用商店前，请确保遵守相关平台的政策和规定
