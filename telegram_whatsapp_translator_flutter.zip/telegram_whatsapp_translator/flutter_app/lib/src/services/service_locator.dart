import 'package:get_it/get_it.dart';
import 'telegram_service.dart';
import 'translation_service.dart';
import 'settings_service.dart';
import '../utils/logger.dart';

final GetIt getIt = GetIt.instance;

Future<void> setupServiceLocator() async {
  // 注册服务
  getIt.registerLazySingleton<TelegramService>(() => TelegramService());
  getIt.registerLazySingleton<TranslationService>(() => TranslationService());
  getIt.registerLazySingleton<SettingsService>(() => SettingsService());
  
  // 初始化服务
  try {
    final telegramService = getIt<TelegramService>();
    await telegramService.initialize();
    
    Logger.log('服务定位器设置成功');
  } catch (e) {
    Logger.error('服务定位器设置失败: $e');
    throw Exception('服务定位器设置失败: $e');
  }
}
