import 'package:shared_preferences/shared_preferences.dart';
import '../utils/logger.dart';

class Settings {
  final bool translateIncoming;
  final bool translateOutgoing;
  final String displayMode; // 'both', 'original', 'translated'
  final String translationService; // 'baidu', 'google', 'youdao'
  final bool enableCache;

  Settings({
    required this.translateIncoming,
    required this.translateOutgoing,
    required this.displayMode,
    required this.translationService,
    required this.enableCache,
  });

  // 从JSON创建设置对象
  factory Settings.fromJson(Map<String, dynamic> json) {
    return Settings(
      translateIncoming: json['translateIncoming'] ?? true,
      translateOutgoing: json['translateOutgoing'] ?? true,
      displayMode: json['displayMode'] ?? 'both',
      translationService: json['translationService'] ?? 'baidu',
      enableCache: json['enableCache'] ?? true,
    );
  }

  // 转换为JSON
  Map<String, dynamic> toJson() {
    return {
      'translateIncoming': translateIncoming,
      'translateOutgoing': translateOutgoing,
      'displayMode': displayMode,
      'translationService': translationService,
      'enableCache': enableCache,
    };
  }

  // 创建默认设置
  factory Settings.defaultSettings() {
    return Settings(
      translateIncoming: true,
      translateOutgoing: true,
      displayMode: 'both',
      translationService: 'baidu',
      enableCache: true,
    );
  }
}

class SettingsService {
  static final SettingsService _instance = SettingsService._internal();
  
  factory SettingsService() {
    return _instance;
  }
  
  SettingsService._internal();
  
  // 获取设置
  Future<Settings> getSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final translateIncoming = prefs.getBool('translateIncoming') ?? true;
      final translateOutgoing = prefs.getBool('translateOutgoing') ?? true;
      final displayMode = prefs.getString('displayMode') ?? 'both';
      final translationService = prefs.getString('translationService') ?? 'baidu';
      final enableCache = prefs.getBool('enableCache') ?? true;
      
      return Settings(
        translateIncoming: translateIncoming,
        translateOutgoing: translateOutgoing,
        displayMode: displayMode,
        translationService: translationService,
        enableCache: enableCache,
      );
    } catch (e) {
      Logger.error('获取设置失败: $e');
      return Settings.defaultSettings();
    }
  }
  
  // 保存设置
  Future<void> saveSettings(Settings settings) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('translateIncoming', settings.translateIncoming);
      await prefs.setBool('translateOutgoing', settings.translateOutgoing);
      await prefs.setString('displayMode', settings.displayMode);
      await prefs.setString('translationService', settings.translationService);
      await prefs.setBool('enableCache', settings.enableCache);
      
      Logger.log('设置已保存');
    } catch (e) {
      Logger.error('保存设置失败: $e');
      throw Exception('保存设置失败: $e');
    }
  }
  
  // 清除翻译缓存
  Future<void> clearTranslationCache() async {
    try {
      // 调用翻译服务清除缓存
      // 这里只是示例，实际实现需要调用翻译服务的清除缓存方法
      Logger.log('翻译缓存已清除');
    } catch (e) {
      Logger.error('清除翻译缓存失败: $e');
      throw Exception('清除翻译缓存失败: $e');
    }
  }
}
