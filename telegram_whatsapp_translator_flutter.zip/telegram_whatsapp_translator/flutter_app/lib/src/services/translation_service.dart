import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';
import '../utils/logger.dart';

class TranslationService {
  static final TranslationService _instance = TranslationService._internal();
  
  factory TranslationService() {
    return _instance;
  }
  
  TranslationService._internal();
  
  // 百度翻译API配置
  final String _baiduAppId = 'YOUR_BAIDU_APP_ID';
  final String _baiduAppSecret = 'YOUR_BAIDU_APP_SECRET';
  final String _baiduApiUrl = 'https://api.fanyi.baidu.com/api/trans/vip/translate';
  
  // 翻译缓存
  final Map<String, String> _translationCache = {};
  
  // 使用百度翻译API翻译文本
  Future<String> translateText(String text, {required String from, required String to}) async {
    // 检查缓存
    final cacheKey = '$from:$to:$text';
    if (_translationCache.containsKey(cacheKey)) {
      Logger.log('使用缓存的翻译结果: $cacheKey');
      return _translationCache[cacheKey]!;
    }
    
    try {
      // 生成随机数
      final salt = DateTime.now().millisecondsSinceEpoch.toString();
      
      // 计算签名
      final sign = md5.convert(utf8.encode('$_baiduAppId$text$salt$_baiduAppSecret')).toString();
      
      // 构建请求参数
      final params = {
        'q': text,
        'from': from,
        'to': to,
        'appid': _baiduAppId,
        'salt': salt,
        'sign': sign,
      };
      
      // 发送请求
      final response = await http.get(
        Uri.parse(_baiduApiUrl).replace(queryParameters: params),
      );
      
      // 解析响应
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        
        if (data.containsKey('trans_result')) {
          final result = data['trans_result'][0]['dst'];
          
          // 缓存翻译结果
          _translationCache[cacheKey] = result;
          
          return result;
        } else if (data.containsKey('error_code')) {
          throw Exception('翻译错误: ${data['error_msg']}');
        }
      }
      
      throw Exception('翻译请求失败: ${response.statusCode}');
    } catch (e) {
      Logger.error('翻译失败: $e');
      
      // 模拟翻译结果（仅用于演示）
      if (from == 'zh' && to == 'en') {
        final mockResult = _mockChineseToEnglish(text);
        _translationCache[cacheKey] = mockResult;
        return mockResult;
      } else if (from == 'en' && to == 'zh') {
        final mockResult = _mockEnglishToChinese(text);
        _translationCache[cacheKey] = mockResult;
        return mockResult;
      }
      
      return '翻译失败';
    }
  }
  
  // 清除翻译缓存
  void clearCache() {
    _translationCache.clear();
  }
  
  // 模拟中译英（仅用于演示）
  String _mockChineseToEnglish(String text) {
    final mockTranslations = {
      '你好': 'Hello',
      '早上好': 'Good morning',
      '晚上好': 'Good evening',
      '谢谢': 'Thank you',
      '再见': 'Goodbye',
      '我很好': 'I\'m fine',
      '我叫': 'My name is',
      '我喜欢': 'I like',
      '我不喜欢': 'I don\'t like',
      '我想': 'I want',
      '我不想': 'I don\'t want',
      '我需要': 'I need',
      '我不需要': 'I don\'t need',
      '我知道': 'I know',
      '我不知道': 'I don\'t know',
      '我明白': 'I understand',
      '我不明白': 'I don\'t understand',
      '我同意': 'I agree',
      '我不同意': 'I disagree',
      '我爱你': 'I love you',
    };
    
    // 简单替换
    String result = text;
    mockTranslations.forEach((key, value) {
      result = result.replaceAll(key, value);
    });
    
    // 如果没有变化，返回一个默认翻译
    if (result == text) {
      return 'This is a translated text from Chinese to English.';
    }
    
    return result;
  }
  
  // 模拟英译中（仅用于演示）
  String _mockEnglishToChinese(String text) {
    final mockTranslations = {
      'Hello': '你好',
      'Good morning': '早上好',
      'Good evening': '晚上好',
      'Thank you': '谢谢',
      'Goodbye': '再见',
      'I\'m fine': '我很好',
      'My name is': '我叫',
      'I like': '我喜欢',
      'I don\'t like': '我不喜欢',
      'I want': '我想',
      'I don\'t want': '我不想',
      'I need': '我需要',
      'I don\'t need': '我不需要',
      'I know': '我知道',
      'I don\'t know': '我不知道',
      'I understand': '我明白',
      'I don\'t understand': '我不明白',
      'I agree': '我同意',
      'I disagree': '我不同意',
      'I love you': '我爱你',
    };
    
    // 简单替换
    String result = text;
    mockTranslations.forEach((key, value) {
      result = result.replaceAll(key, value);
    });
    
    // 如果没有变化，返回一个默认翻译
    if (result == text) {
      return '这是一段从英文翻译成中文的文本。';
    }
    
    return result;
  }
}
