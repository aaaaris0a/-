import 'package:flutter/material.dart';
import '../../models/message.dart';

class MessageBubble extends StatelessWidget {
  final Message message;

  const MessageBubble({Key? key, required this.message}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isIncoming = message.isIncoming;
    final theme = Theme.of(context);
    
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: isIncoming ? MainAxisAlignment.start : MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (isIncoming) _buildAvatar(context),
          
          const SizedBox(width: 8),
          
          Flexible(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isIncoming 
                    ? theme.brightness == Brightness.light 
                        ? Colors.grey.shade200 
                        : Colors.grey.shade800
                    : theme.primaryColor.withOpacity(0.8),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 原文
                  Text(
                    message.text,
                    style: TextStyle(
                      color: isIncoming 
                          ? theme.textTheme.bodyText1?.color 
                          : Colors.white,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  
                  const SizedBox(height: 4),
                  
                  // 译文
                  if (message.translatedText != null)
                    Text(
                      message.translatedText!,
                      style: TextStyle(
                        color: isIncoming 
                            ? theme.textTheme.caption?.color 
                            : Colors.white.withOpacity(0.8),
                        fontStyle: FontStyle.italic,
                        fontSize: 13,
                      ),
                    ),
                  
                  const SizedBox(height: 4),
                  
                  // 时间
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        _formatTime(message.time),
                        style: TextStyle(
                          color: isIncoming 
                              ? theme.textTheme.caption?.color 
                              : Colors.white.withOpacity(0.7),
                          fontSize: 11,
                        ),
                      ),
                      const SizedBox(width: 4),
                      if (!isIncoming)
                        Icon(
                          Icons.done_all,
                          size: 14,
                          color: Colors.white.withOpacity(0.7),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(width: 8),
          
          if (!isIncoming) _buildAvatar(context),
        ],
      ),
    );
  }

  Widget _buildAvatar(BuildContext context) {
    return CircleAvatar(
      radius: 16,
      backgroundColor: message.isIncoming 
          ? Colors.grey.shade400 
          : Theme.of(context).primaryColor,
      child: Text(
        message.isIncoming 
            ? message.sender.substring(0, 1) 
            : 'M',
        style: const TextStyle(
          color: Colors.white,
          fontSize: 12,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
  }
}
