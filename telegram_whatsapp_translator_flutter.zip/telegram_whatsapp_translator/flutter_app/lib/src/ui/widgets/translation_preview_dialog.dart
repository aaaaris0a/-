import 'package:flutter/material.dart';

class TranslationPreviewDialog extends StatefulWidget {
  final String originalText;
  final String translatedText;

  const TranslationPreviewDialog({
    Key? key,
    required this.originalText,
    required this.translatedText,
  }) : super(key: key);

  @override
  State<TranslationPreviewDialog> createState() => _TranslationPreviewDialogState();
}

class _TranslationPreviewDialogState extends State<TranslationPreviewDialog> {
  late TextEditingController _translatedController;

  @override
  void initState() {
    super.initState();
    _translatedController = TextEditingController(text: widget.translatedText);
  }

  @override
  void dispose() {
    _translatedController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('翻译预览'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('原文:'),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(8),
            margin: const EdgeInsets.only(bottom: 16, top: 4),
            decoration: BoxDecoration(
              color: Colors.grey.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(widget.originalText),
          ),
          const Text('译文:'),
          const SizedBox(height: 4),
          TextField(
            controller: _translatedController,
            decoration: const InputDecoration(
              hintText: '编辑翻译结果',
              border: OutlineInputBorder(),
            ),
            maxLines: 3,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: const Text('取消'),
        ),
        ElevatedButton(
          onPressed: () => Navigator.of(context).pop(true),
          child: const Text('发送'),
        ),
      ],
    );
  }
}
