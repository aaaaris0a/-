import 'package:flutter/material.dart';
import '../../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // 设置选项
  bool _translateIncoming = true;
  bool _translateOutgoing = true;
  String _displayMode = 'both'; // 'both', 'original', 'translated'
  String _translationService = 'baidu'; // 'baidu', 'google', 'youdao'
  bool _enableCache = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  // 加载设置
  Future<void> _loadSettings() async {
    final settings = await SettingsService().getSettings();
    setState(() {
      _translateIncoming = settings.translateIncoming;
      _translateOutgoing = settings.translateOutgoing;
      _displayMode = settings.displayMode;
      _translationService = settings.translationService;
      _enableCache = settings.enableCache;
    });
  }

  // 保存设置
  Future<void> _saveSettings() async {
    final settings = Settings(
      translateIncoming: _translateIncoming,
      translateOutgoing: _translateOutgoing,
      displayMode: _displayMode,
      translationService: _translationService,
      enableCache: _enableCache,
    );
    await SettingsService().saveSettings(settings);
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('设置已保存')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('设置'),
      ),
      body: ListView(
        children: [
          // 翻译设置
          _buildSectionHeader('翻译设置'),
          SwitchListTile(
            title: const Text('接收消息自动翻译'),
            subtitle: const Text('将收到的外语消息自动翻译为中文'),
            value: _translateIncoming,
            onChanged: (value) {
              setState(() {
                _translateIncoming = value;
              });
            },
          ),
          SwitchListTile(
            title: const Text('发送消息自动翻译'),
            subtitle: const Text('将发送的中文消息自动翻译为英文'),
            value: _translateOutgoing,
            onChanged: (value) {
              setState(() {
                _translateOutgoing = value;
              });
            },
          ),
          
          // 显示设置
          _buildSectionHeader('显示设置'),
          ListTile(
            title: const Text('显示方式'),
            subtitle: Text(_getDisplayModeText()),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: _showDisplayModeDialog,
          ),
          
          // 翻译服务设置
          _buildSectionHeader('翻译服务'),
          ListTile(
            title: const Text('翻译服务提供商'),
            subtitle: Text(_getTranslationServiceText()),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: _showTranslationServiceDialog,
          ),
          
          // 高级设置
          _buildSectionHeader('高级设置'),
          SwitchListTile(
            title: const Text('启用翻译缓存'),
            subtitle: const Text('缓存翻译结果以提高性能'),
            value: _enableCache,
            onChanged: (value) {
              setState(() {
                _enableCache = value;
              });
            },
          ),
          ListTile(
            title: const Text('清除翻译缓存'),
            subtitle: const Text('删除所有缓存的翻译结果'),
            onTap: () {
              // 清除缓存
              SettingsService().clearTranslationCache();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('翻译缓存已清除')),
              );
            },
          ),
          
          // 联系人规则
          _buildSectionHeader('联系人规则'),
          ListTile(
            title: const Text('特定联系人翻译规则'),
            subtitle: const Text('为不同联系人设置自定义翻译规则'),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              // 导航到联系人规则界面
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => const Scaffold(
                    appBar: AppBar(title: Text('联系人规则')),
                    body: Center(child: Text('联系人规则界面')),
                  ),
                ),
              );
            },
          ),
          
          // 关于
          _buildSectionHeader('关于'),
          ListTile(
            title: const Text('应用版本'),
            subtitle: const Text('1.0.0'),
          ),
          ListTile(
            title: const Text('开发者'),
            subtitle: const Text('自动翻译消息助手团队'),
          ),
          
          // 保存按钮
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: _saveSettings,
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(double.infinity, 50),
              ),
              child: const Text('保存设置'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: TextStyle(
          color: Theme.of(context).primaryColor,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _getDisplayModeText() {
    switch (_displayMode) {
      case 'both':
        return '同时显示原文和译文';
      case 'original':
        return '只显示原文';
      case 'translated':
        return '只显示译文';
      default:
        return '同时显示原文和译文';
    }
  }

  String _getTranslationServiceText() {
    switch (_translationService) {
      case 'baidu':
        return '百度翻译';
      case 'google':
        return '谷歌翻译';
      case 'youdao':
        return '有道翻译';
      default:
        return '百度翻译';
    }
  }

  Future<void> _showDisplayModeDialog() async {
    final result = await showDialog<String>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('选择显示方式'),
        children: [
          _buildDialogOption('both', '同时显示原文和译文'),
          _buildDialogOption('original', '只显示原文'),
          _buildDialogOption('translated', '只显示译文'),
        ],
      ),
    );

    if (result != null) {
      setState(() {
        _displayMode = result;
      });
    }
  }

  Future<void> _showTranslationServiceDialog() async {
    final result = await showDialog<String>(
      context: context,
      builder: (context) => SimpleDialog(
        title: const Text('选择翻译服务提供商'),
        children: [
          _buildDialogOption('baidu', '百度翻译'),
          _buildDialogOption('google', '谷歌翻译'),
          _buildDialogOption('youdao', '有道翻译'),
        ],
      ),
    );

    if (result != null) {
      setState(() {
        _translationService = result;
      });
    }
  }

  Widget _buildDialogOption(String value, String text) {
    return SimpleDialogOption(
      onPressed: () => Navigator.of(context).pop(value),
      child: Text(text),
    );
  }
}
