import 'package:flutter/material.dart';
import '../../models/chat.dart';
import '../../models/message.dart';
import '../../services/translation_service.dart';
import '../widgets/message_bubble.dart';
import '../widgets/translation_preview_dialog.dart';

class ChatScreen extends StatefulWidget {
  final Chat chat;

  const ChatScreen({Key? key, required this.chat}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<Message> _messages = [];
  bool _isTranslating = false;

  @override
  void initState() {
    super.initState();
    _loadMessages();
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  // 加载消息历史
  void _loadMessages() {
    // 示例消息数据
    setState(() {
      _messages.addAll([
        Message(
          id: '1',
          text: 'Hello, how are you?',
          translatedText: '你好，你好吗？',
          isIncoming: true,
          time: DateTime.now().subtract(const Duration(minutes: 30)),
          sender: widget.chat.name,
        ),
        Message(
          id: '2',
          text: '我很好，谢谢！你呢？',
          translatedText: 'I\'m fine, thank you! And you?',
          isIncoming: false,
          time: DateTime.now().subtract(const Duration(minutes: 28)),
          sender: 'Me',
        ),
        Message(
          id: '3',
          text: 'I\'m doing great! What are your plans for today?',
          translatedText: '我很好！你今天有什么计划？',
          isIncoming: true,
          time: DateTime.now().subtract(const Duration(minutes: 25)),
          sender: widget.chat.name,
        ),
        Message(
          id: '4',
          text: '我计划去图书馆学习，然后晚上和朋友吃饭。',
          translatedText: 'I plan to study at the library, then have dinner with friends in the evening.',
          isIncoming: false,
          time: DateTime.now().subtract(const Duration(minutes: 20)),
          sender: 'Me',
        ),
        Message(
          id: '5',
          text: 'That sounds nice! I\'ll be working on my project all day.',
          translatedText: '听起来不错！我将整天都在做我的项目。',
          isIncoming: true,
          time: DateTime.now().subtract(const Duration(minutes: 15)),
          sender: widget.chat.name,
        ),
      ]);
    });

    // 滚动到底部
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _scrollToBottom();
    });
  }

  // 滚动到底部
  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  // 发送消息
  Future<void> _sendMessage() async {
    final text = _messageController.text.trim();
    if (text.isEmpty) return;

    // 清空输入框
    _messageController.clear();

    setState(() {
      _isTranslating = true;
    });

    try {
      // 调用翻译服务
      final translatedText = await TranslationService().translateText(
        text,
        from: 'zh',
        to: 'en',
      );

      // 显示翻译预览对话框
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => TranslationPreviewDialog(
          originalText: text,
          translatedText: translatedText,
        ),
      );

      if (confirmed == true) {
        // 添加消息到列表
        final newMessage = Message(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          text: text,
          translatedText: translatedText,
          isIncoming: false,
          time: DateTime.now(),
          sender: 'Me',
        );

        setState(() {
          _messages.add(newMessage);
          _isTranslating = false;
        });

        // 滚动到底部
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _scrollToBottom();
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('翻译失败: ${e.toString()}')),
      );
      setState(() {
        _isTranslating = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.chat.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {
              // 更多选项
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // 消息列表
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length,
              itemBuilder: (context, index) {
                final message = _messages[index];
                return MessageBubble(message: message);
              },
            ),
          ),
          
          // 输入区域
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  offset: const Offset(0, -1),
                  blurRadius: 4,
                ),
              ],
            ),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.attach_file),
                  onPressed: () {
                    // 附件功能
                  },
                ),
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: '输入消息...',
                      border: InputBorder.none,
                    ),
                    maxLines: null,
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _sendMessage(),
                  ),
                ),
                _isTranslating
                    ? const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      )
                    : IconButton(
                        icon: const Icon(Icons.send),
                        color: Theme.of(context).primaryColor,
                        onPressed: _sendMessage,
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
