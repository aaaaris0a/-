import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/telegram_service.dart';
import 'chat_list_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _codeController = TextEditingController();
  bool _showCodeInput = false;
  bool _isLoading = false;
  String _errorMessage = '';

  @override
  void dispose() {
    _phoneController.dispose();
    _codeController.dispose();
    super.dispose();
  }

  // 发送手机号码
  Future<void> _sendPhoneNumber() async {
    final phoneNumber = _phoneController.text.trim();
    if (phoneNumber.isEmpty) {
      setState(() {
        _errorMessage = '请输入手机号码';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      // 调用Telegram服务发送手机号码
      await context.read<TelegramService>().sendPhoneNumber(phoneNumber);
      
      // 显示验证码输入
      setState(() {
        _showCodeInput = true;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = '发送手机号码失败: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  // 发送验证码
  Future<void> _sendVerificationCode() async {
    final code = _codeController.text.trim();
    if (code.isEmpty) {
      setState(() {
        _errorMessage = '请输入验证码';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      // 调用Telegram服务发送验证码
      await context.read<TelegramService>().sendVerificationCode(code);
      
      // 登录成功，导航到聊天列表界面
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const ChatListScreen()),
      );
    } catch (e) {
      setState(() {
        _errorMessage = '验证码错误: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // 应用Logo
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.translate,
                  size: 50,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 20),
              
              // 应用标题
              Text(
                '自动翻译消息助手',
                style: Theme.of(context).textTheme.headline6,
              ),
              const SizedBox(height: 30),
              
              // 错误消息
              if (_errorMessage.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(10),
                  margin: const EdgeInsets.only(bottom: 20),
                  decoration: BoxDecoration(
                    color: Colors.red.shade100,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    _errorMessage,
                    style: TextStyle(color: Colors.red.shade800),
                  ),
                ),
              
              // 手机号码输入
              if (!_showCodeInput) ...[
                TextField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    labelText: '输入手机号码',
                    hintText: '例如: +86 123 4567 8901',
                    prefixIcon: Icon(Icons.phone),
                  ),
                  keyboardType: TextInputType.phone,
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _isLoading ? null : _sendPhoneNumber,
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 50),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('下一步'),
                ),
              ],
              
              // 验证码输入
              if (_showCodeInput) ...[
                TextField(
                  controller: _codeController,
                  decoration: const InputDecoration(
                    labelText: '输入验证码',
                    hintText: 'Telegram发送的验证码',
                    prefixIcon: Icon(Icons.lock),
                  ),
                  keyboardType: TextInputType.number,
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _isLoading ? null : _sendVerificationCode,
                  style: ElevatedButton.styleFrom(
                    minimumSize: const Size(double.infinity, 50),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text('登录'),
                ),
              ],
              
              const SizedBox(height: 30),
              
              // 应用说明
              const Text(
                '应用说明：',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const Text('• 自动将收到的消息翻译成中文'),
              const Text('• 自动将发送的消息翻译成英文'),
              const Text('• 支持在设置中自定义翻译规则'),
            ],
          ),
        ),
      ),
    );
  }
}
