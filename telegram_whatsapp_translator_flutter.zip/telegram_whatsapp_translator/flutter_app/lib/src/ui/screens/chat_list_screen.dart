import 'package:flutter/material.dart';
import '../../models/chat.dart';
import 'chat_screen.dart';
import 'settings_screen.dart';

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({Key? key}) : super(key: key);

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen> {
  final List<Chat> _chats = [
    // 示例聊天数据
    Chat(
      id: '1',
      name: 'John Smith',
      lastMessage: 'Hello, how are you?',
      time: DateTime.now().subtract(const Duration(minutes: 5)),
      unreadCount: 2,
      avatarUrl: null,
    ),
    Chat(
      id: '2',
      name: 'Alice Johnson',
      lastMessage: 'Are you coming to the meeting?',
      time: DateTime.now().subtract(const Duration(hours: 1)),
      unreadCount: 0,
      avatarUrl: null,
    ),
    Chat(
      id: '3',
      name: 'Bob Williams',
      lastMessage: 'I sent you the document.',
      time: DateTime.now().subtract(const Duration(hours: 3)),
      unreadCount: 1,
      avatarUrl: null,
    ),
    Chat(
      id: '4',
      name: 'Emma Davis',
      lastMessage: 'Thanks for your help!',
      time: DateTime.now().subtract(const Duration(days: 1)),
      unreadCount: 0,
      avatarUrl: null,
    ),
    Chat(
      id: '5',
      name: 'Michael Brown',
      lastMessage: 'Let\'s discuss this tomorrow.',
      time: DateTime.now().subtract(const Duration(days: 2)),
      unreadCount: 0,
      avatarUrl: null,
    ),
  ];

  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('聊天'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {
              // 搜索功能
            },
          ),
        ],
      ),
      body: _buildBody(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
          
          // 如果点击设置，导航到设置界面
          if (index == 1) {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ).then((_) {
              // 返回后重置为聊天标签
              setState(() {
                _currentIndex = 0;
              });
            });
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: '聊天',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: '设置',
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return ListView.separated(
      itemCount: _chats.length,
      separatorBuilder: (context, index) => const Divider(height: 1),
      itemBuilder: (context, index) {
        final chat = _chats[index];
        return ListTile(
          leading: CircleAvatar(
            backgroundColor: Theme.of(context).primaryColor,
            child: chat.avatarUrl == null
                ? Text(
                    chat.name.substring(0, 1),
                    style: const TextStyle(color: Colors.white),
                  )
                : null,
            backgroundImage:
                chat.avatarUrl != null ? NetworkImage(chat.avatarUrl!) : null,
          ),
          title: Text(chat.name),
          subtitle: Text(
            chat.lastMessage,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _formatTime(chat.time),
                style: TextStyle(
                  fontSize: 12,
                  color: Theme.of(context).textTheme.caption?.color,
                ),
              ),
              const SizedBox(height: 4),
              if (chat.unreadCount > 0)
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor,
                    shape: BoxShape.circle,
                  ),
                  child: Text(
                    chat.unreadCount.toString(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                    ),
                  ),
                ),
            ],
          ),
          onTap: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (_) => ChatScreen(chat: chat),
              ),
            );
          },
        );
      },
    );
  }

  String _formatTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);

    if (difference.inDays > 0) {
      return '${difference.inDays}天前';
    } else if (difference.inHours > 0) {
      return '${difference.inHours}小时前';
    } else if (difference.inMinutes > 0) {
      return '${difference.inMinutes}分钟前';
    } else {
      return '刚刚';
    }
  }
}
