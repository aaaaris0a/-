class Chat {
  final String id;
  final String name;
  final String lastMessage;
  final DateTime time;
  final int unreadCount;
  final String? avatarUrl;

  Chat({
    required this.id,
    required this.name,
    required this.lastMessage,
    required this.time,
    required this.unreadCount,
    this.avatarUrl,
  });

  // 从JSON创建聊天对象
  factory Chat.fromJson(Map<String, dynamic> json) {
    return Chat(
      id: json['id'],
      name: json['name'],
      lastMessage: json['lastMessage'],
      time: json['time'] is DateTime ? json['time'] : DateTime.now(),
      unreadCount: json['unreadCount'] ?? 0,
      avatarUrl: json['avatarUrl'],
    );
  }

  // 转换为JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'lastMessage': lastMessage,
      'time': time.toIso8601String(),
      'unreadCount': unreadCount,
      'avatarUrl': avatarUrl,
    };
  }
}
