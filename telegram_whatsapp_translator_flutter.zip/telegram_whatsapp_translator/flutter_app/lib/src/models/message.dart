class Message {
  final String id;
  final String text;
  final String? translatedText;
  final bool isIncoming;
  final DateTime time;
  final String sender;

  Message({
    required this.id,
    required this.text,
    this.translatedText,
    required this.isIncoming,
    required this.time,
    required this.sender,
  });

  // 从JSON创建消息对象
  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      id: json['id'],
      text: json['text'],
      translatedText: json['translatedText'],
      isIncoming: json['isIncoming'],
      time: json['time'] is DateTime ? json['time'] : DateTime.now(),
      sender: json['sender'],
    );
  }

  // 转换为JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'text': text,
      'translatedText': translatedText,
      'isIncoming': isIncoming,
      'time': time.toIso8601String(),
      'sender': sender,
    };
  }
}
