import 'package:flutter/material.dart';

class Logger {
  static void log(String message) {
    debugPrint('LOG: $message');
  }
  
  static void error(String message) {
    debugPrint('ERROR: $message');
  }
  
  static void warning(String message) {
    debugPrint('WARNING: $message');
  }
  
  static void info(String message) {
    debugPrint('INFO: $message');
  }
}
